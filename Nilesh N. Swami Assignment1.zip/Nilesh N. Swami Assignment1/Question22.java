package com.Assignment;

import java.util.Scanner;

public class Question22 {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		Question22 que =new Question22();
		System.out.println("Enter your Binary number:");
		int num = in.nextInt();
		int a=0,n=1;
		while(num>0)
		{
			int rem = num%10;
			a = (rem*n)+a;
			n*=2;
			num/=10;
		}
		System.out.println("Dacimal:"+a);
	}

}
