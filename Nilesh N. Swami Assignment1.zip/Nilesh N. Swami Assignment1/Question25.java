package com.Assignment;
import java.util.Scanner;
public class Question25 {

	 public static void main(String args[])
		{

			Scanner in = new Scanner(System.in);	
			System.out.println("Enter your first number:");
			int num1 =in.nextInt() ;
			int dec=0;
			int i=0;
			while(num1!=0)
			{
				int r =num1%10;
				 dec =(int) (dec+r*Math.pow(8,i++));
				num1/=10; 	
			}System.out.println(dec);
		}
}
