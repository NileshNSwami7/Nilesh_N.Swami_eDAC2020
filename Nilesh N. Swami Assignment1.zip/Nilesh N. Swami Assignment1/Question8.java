package com.Assignment;

public class Question8 {
	
	public static void main(String[] args) {
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n-1;j++)
			{
				if(((j==n-1||i==n)&&(j==n || j!=i-1)&&(i==n-1 || j!=n/2-1)||(i==n-1 && j==n/2-1)))        
				{
					System.out.print("J");
				}
				else {
					System.out.print(" ");
				}
				
			}	System.out.println();
		}
		int c=n;
		for (int i=1;i<=n;i++,c--)
		{
			for(int j=1;j<=2*n-1;j++)
			{
				if((j==c || j==n+i-1 )|| (j>=c &&  j<=n+i-1 && i==n/2+1))
				{
					System.out.print("A");
				}
				else {
					System.out.print(" ");
				}
				
			}System.out.println();
	}
		int k=1;
		for (int i=1;i<=n;i++,k++)
		{
			for(int j=1;j<=2*n;j++)
			{
				if((j==k ||j>=2*n-k && j<=2*n-k))
				{
					System.out.print("v");
				}
				else {
					System.out.print(" ");
				}
			}System.out.println();
	}
		int l=n;
		for(int i=1;i<=n;i++,l--)
		{
			for(int j=1;j<2*n;j++)
			{
				if(j==l || j==n+(i-1) ||(j>=l && j<=n+(i-1) && i==n/2+1))
						{
					System.out.print("A");
						}
				else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}	
	
}