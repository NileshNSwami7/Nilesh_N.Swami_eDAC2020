package com.Assignment;

import java.util.Scanner;

public class Question17 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Question17 que = new Question17();
		int i,num,num1,rem=0,a=0;
		int add[]=new int[10];
		System.out.println("Enter the two binary numbers:");
		num=in.nextInt();
		num1=in.nextInt();
		
		for( i=0;num!=0||num1!=0;i++)
		{
			add[i]=(int)((num%10+num1%10+rem)%2);
			
			rem=(int)((num%10+num1%10+rem)/2);
			num/=10;
			num1/=10;	
		}
		if(rem!=0)
		{
			add[i++]=rem;
		}		
			--i;
		System.out.println("addition of binary:");
		 for(;i>=0;)
				{
			 		System.out.print(add[i--]);
				}
		}

}
