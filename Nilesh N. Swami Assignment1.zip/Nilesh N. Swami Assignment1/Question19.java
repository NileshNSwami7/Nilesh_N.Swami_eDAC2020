package com.Assignment;

public class Question19 {

	public static void main(String[] args) {
		
		int num = 5,r;
		String rem="";
		
		while(num!=0) {
			r=num%2;
			rem=rem + r;
			num=num/2;
		}
		System.out.println("Binary:"+rem);
	}

}
