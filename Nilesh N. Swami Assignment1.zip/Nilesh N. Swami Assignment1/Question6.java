package com.Assignment;

import java.util.Scanner;

public class Question6 {
	
	public int Addition(int num1,int num2) {
		
		int result;
		result=num1+num2;
		System.out.println("Sum:"+result);
		return result;
	}
	public int Substraction (int num1,int num2)
	{
		int result;
		result = num1-num2;
		System.out.println("Substract:"+result);
		return result;
	}
	
	public int Multiplication(int num1,int num2)
	{
		int result;
		result = num1*num2;
		System.out.println("Multiplication:"+result);
		return result;
	}
	public int Divide(int num1,int num2) {
		int result;
		result=num1/num2;
		System.out.println("Divid:"+result);
		return result;
	}
	public int Reminder(int num1,int num2)
	{
		int result;
		result = num1%num2;
		System.out.println("Reminder:"+result);
		return result;
	}
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		Question6 que = new Question6();	
		System.out.println("Please enter two numbers:");
		int num1 = in.nextInt();
		int num2 = in.nextInt();
		que.Addition(num1, num2);
		que.Substraction(num1, num2);
		que.Multiplication(num1, num2);
		que.Divide(num1, num2);
		que.Reminder(num1, num2);
	}

}
