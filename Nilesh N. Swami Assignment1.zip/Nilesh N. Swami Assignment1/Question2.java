package com.Assignment;

public class Question2 {

	public static void main(String[] args) {
		int num1 =76;
		int num2 =34;
		int sum =0;
	
		sum=num1+num2;
		System.out.println("Sum:"+sum);
	}

}
