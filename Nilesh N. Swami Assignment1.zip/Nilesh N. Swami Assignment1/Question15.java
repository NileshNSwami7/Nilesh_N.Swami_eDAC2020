package com.Assignment;

import java.util.Scanner;

public class Question15 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Question15 que = new Question15();
		int num,num1,temp=0;
		System.out.println("Enter two numbers:");
		num=in.nextInt();
		num1=in.nextInt();
		System.out.println("Before Swapping variables:"+num+":"+num1);
		temp=num;
		num=num1;
		num1=temp;
		System.out.println("After Swapping variables:"+num+":"+num1);
	}

}
