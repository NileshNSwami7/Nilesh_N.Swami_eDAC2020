package com.Assignment;

public class Question3 {

	public static void main(String[] args) {
		
		int num1=50;
		int num2=3;
		int result=0;
		
		result=num1/num2 ;
		System.out.println("Result:"+result);
	}

}
