package com.Assignment;

public class Question9 {

	public static void main(String[] args) {
		
		double result;
		
		result = ((25.5*3.5-3.5*3.5)/(40.5-4.5));
		System.out.println("Result:"+result);

	}

}
