package com.Assignment;

import java.util.Scanner;

public class Question12 {
	
	public double average(int num,int num1,int num2)
	{
		double avg;
		avg=((num+num1+num2)/3);
		System.out.println("Avarge of numbers:"+avg);
		return avg;
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Question12 que = new Question12();
		System.out.println("Enter three numbers for avarge:");
			int num = in.nextInt();
			int num1 = in.nextInt();
			int num2 = in.nextInt();
			 
			que.average(num,num1,num2);
			
	}

}
