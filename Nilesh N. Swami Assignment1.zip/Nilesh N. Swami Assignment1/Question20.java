package com.Assignment;

import java.util.Scanner;

public class Question20 {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		Question20 que = new Question20();
		System.out.println("Enter no:");
		int num = in.nextInt();
		int arr[] =new int[100];
		int i;
		for( i=0;num!=0;i++)
		{
			arr[i] = num%16;
			num/=16;
		}
		System.out.println("Hexadecimal:");
		for(int j=i-1;j>=0;j--)
		{
			if(arr[j]>9)
			{
				System.out.println((char)(arr[j]+55));
			}
			else {
				System.out.println(arr[j]);
			}
		}
	}

}
