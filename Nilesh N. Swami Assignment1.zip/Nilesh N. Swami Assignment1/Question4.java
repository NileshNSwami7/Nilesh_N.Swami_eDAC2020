package com.Assignment;

public class Question4 {

	public int expressionNo1(int num1,int num2,int num3) {
		int result;
		result=(-num1)+num2*num3;
		System.out.println("Expression1:"+result);
		return result;
	}
	public int expressionNo2(int num1,int num2,int num3) {
		int result;
		result=(num1+num2)%num3;
		System.out.println("Expression2:"+result);
		return result;
	}
	public int expressionNo3(int num1,int num2,int num3,int num4) {
		int result;
		result=num1+(-num2)*num3/num4;
		System.out.println("Expression3:"+result);
		return result;
	}
	public int expressionNo4(int num1,int num2,int num3,int num4,int num5,int num6){
		int result;
		result=num1+num2/num3*num4-num5%num6;
		System.out.println("Expression4:"+result);
		return result;
	}
	
	
	public static void main(String[] args) {
		Question4 que = new Question4();
			que.expressionNo1(5, 8, 6);
			que.expressionNo2(55, 9, 9);
			que.expressionNo3(20, 3, 5, 8);
			que.expressionNo4(5, 15, 3, 2, 8, 3);
	}

}
