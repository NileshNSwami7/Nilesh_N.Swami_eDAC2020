package com.Assignment;
import java.util.Scanner;
public class Question24 {


		public static void main(String args[])
		{
			Scanner in = new Scanner(System.in);
			Question24 que = new Question24();
			System.out.println("Enter your binary no:");
			int arr[] = new int[100];
			int num=in.nextInt();
			int a=1,b=0,i;
			for(;num>0;)
			{
				int n = num%10;
				b=(a*n)+b;
				a=a*2;
				num/=10;
			}
			System.out.println("Decimal number:"+b);
			for( i=0;b!=0;i++)
			{
				arr[i]=b%8;
				b/=8;
			}
			System.out.print("Octal number:");
			for(int j=i-1;j>=0;j--)
			{
				System.out.print(arr[j]);
			}
		}
		
	}							


