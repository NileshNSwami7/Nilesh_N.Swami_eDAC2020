package com.Assignment;

import java.util.Scanner;

public class Question11 {
	public double perimeterofCircle(double redius)
	{
		double perimeter;
		perimeter=2*Math.PI*redius;
		System.out.println("Perimeter of Circle:"+perimeter);
		return perimeter;
	}
	public double  areaofCircle(double redius)
	{
		double Area;
		Area=Math.PI*redius*redius;
		System.out.println("Area of Circle:"+Area);
		return Area;
	}
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		Question11 que = new Question11();
		System.out.println("Enter the redius:");
		double num =in.nextDouble();
		que.perimeterofCircle(num);
		que.areaofCircle(num);
	}

}
