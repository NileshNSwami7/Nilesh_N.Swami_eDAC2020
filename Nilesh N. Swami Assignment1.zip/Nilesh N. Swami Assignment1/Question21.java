package com.Assignment;
import java.util.Scanner;
public class Question21 {
	
		public static void main(String args[])
		{
			Scanner in = new Scanner(System.in);
			System.out.println("Enter the number:");
			int num = in.nextInt();
			int i;
			int arr[] = new int[100];
			
			for(i=0;num!=0;i++)
			{
				arr[i] = num%8;
				num/=8;			
			}
			System.out.println("Decimal number:");
			for(int j=i-1;j>=0;j--)
			{
				System.out.print(arr[j]);
			}
		}
	
}
