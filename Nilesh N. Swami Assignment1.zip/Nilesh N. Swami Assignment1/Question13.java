package com.Assignment;

import java.util.Scanner;

public class Question13 {

	public double areaofRectangle(double height,double width)
	{
		double area;
		area=(width*height);
		System.out.println("Area of Rectangle:"+area);
		return area;
	}
	public double perimeterofRectangle(double height,double width)
	{
		double perimeter;
		perimeter=(2*(height+width));
		System.out.println("Perimeter of perimeter:"+perimeter);
		return perimeter;
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Question13 que = new Question13();
		System.out.println("Enter the Parameters Reactangl:");
		System.out.println("height:");
		double height = in.nextDouble();
		System.out.println("width:");
		double width = in.nextDouble();
		
		que.areaofRectangle(height,width);
		que.perimeterofRectangle(height,width);
	}

}
