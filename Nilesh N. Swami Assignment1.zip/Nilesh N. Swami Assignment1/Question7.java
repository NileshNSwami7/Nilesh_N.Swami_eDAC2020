package com.Assignment;

import java.util.Scanner;

public class Question7 {
		
	public int Table(int num)
	{
		for(int i=1;i<=10;i++)
		{
			int result=num*i;
			System.out.println(num+"*"+i+"="+result);
		}
		return num;
	}
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		Question7 que = new Question7();
		System.out.println("Please enter your number for table:");
		int num = in.nextInt();
		que.Table(num);
	}

}
