package com.Assignment;

import java.util.Scanner;

public class Question23 {

	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		Question23 que = new Question23();
		System.out.println("Please Enter your binary code:");
		int num = in.nextInt();
		int a=0,n=1,i;
		int arr[] = new int[100];
		while(num>0)
		{
			int rem = num%10;
			a=a+(n*rem);
			n*=2;
			num/=10;
		}
		System.out.println("Decimal no.:"+a);
		for(i=0;a!=0;i++)
		{
			arr[i] = a%16;
			a=a/16;
		}
		System.out.println("Hexadecimal no.:");
		for(int j=i-1;j>=0;j--)
		{
			if(arr[j]>9)
			{
				System.out.print((char)(arr[j]+55));
			}
			else
			{
				System.out.print(arr[j]);
			}
		}
	}

}
