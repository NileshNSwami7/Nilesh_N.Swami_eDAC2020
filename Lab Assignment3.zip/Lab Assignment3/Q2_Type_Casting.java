package Assignment3;

import java.util.Scanner;

public class Q2_Type_Casting {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the value");
		
		int b = 500;
		byte i =  (byte)b;
		System.out.println("Byte value after down casting:"+b);
		 
		long l = (long)b;
		System.out.println("Long value after upcasting:"+l);
		
	}

}
