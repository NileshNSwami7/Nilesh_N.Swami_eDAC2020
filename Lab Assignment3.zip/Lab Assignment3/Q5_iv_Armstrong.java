package Assignment3;

import java.util.Scanner;

public class Q5_iv_Armstrong {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the number:");
		int num = sc.nextInt();
		int sum=0;
		int temp = num;
		while(num > 0)
		{
			int res = num%10;
			num/=10;
			sum=sum+(res*res*res);
			
		}
		if(temp==sum)
		{
			System.out.println("Number is Armstrong.");
		}
		else{
			System.out.println("Number is not Armstrong");
		}
	}

}
