package Assignment3;

import java.util.Scanner;

public class Q5_i_prime_Number {

	public static boolean prime(int num)
	{
		for(int i=2;i<=num/2;i++)
		{
			if(num%i==0)
			{ 
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		
		Scanner inp=new Scanner(System.in);
		int num,count=0;
		System.out.println("Enter the number:");
		num=inp.nextInt();
		for(int i=0;count<=num;i++)
		{
			if(prime(i))
			{
				count++;
				if(count==num)
				System.out.println("Prime number are:"+i);
			}
			
		}
		
	}

}
