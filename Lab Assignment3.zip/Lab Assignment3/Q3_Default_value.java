package Assignment3;
import java.util.Scanner;
public class Q3_Default_value {

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		byte b = 0;
		System.out.println("Default value of byte:"+b);
		Short s = null;
		System.out.println("Default value of short:"+s);
		int i = 0;
		System.out.println("Default value of int:"+i);
		long l = 0;
		System.out.println("Default value of long:"+l);
		float f = 0;
		System.out.println("Default value of float:"+f);
		double d = 0;
		System.out.println("Default value of default:"+d);
		char ch = 0 ;
		System.out.println("Default value of char:"+ch);
		boolean b1 = false;
		System.out.println("Deafult value of booelan:"+b1);
	}

}
