package Assignment3;

import java.util.Scanner;

public class Q1_Pre_Post_operatror {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("please enter the statement");
		int x = sc.nextInt();
		
		int y = ++x;
		System.out.println("Pre add:"+y);
		int y1 = x++;
		System.out.println("post add:"+y1);
	}

}
