package Assignment3;

import java.util.Scanner;

public class Q5_ii_Even_Odd {

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number ");
		int num = sc.nextInt();
		int e_Sum=0;
		int o_Sum=0;
		for(int i=0;i<num;i++)
		{
			if(i%2==0)
			{
				e_Sum+=i;
				System.out.println("Even number:"+e_Sum);
			}
			else
			{
				o_Sum+=i;
				System.out.println("Odd number:"+o_Sum);
			}
		}

	}

}
