package Assignment3;

import java.util.Scanner;

public class Q5_iii_Fibonacci_Series {

	
	public static void main(String[] args) {
		
		int num,temp=0,result=1,count=0;
		Scanner inp=new Scanner(System.in);
		System.out.println("Enter the number:");
		num=inp.nextInt();
		int x=0;
		for(int i=0;i<num;i++)
		{
			temp=x;
			x=result;
			result=result+temp;
			count++;
			System.out.println("Fibonacci series:"+count+" "+"NO:"+result);
		}
	}

}
