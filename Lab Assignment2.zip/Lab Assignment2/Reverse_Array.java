

import java.util.Scanner;

public class Reverse_Array {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the size of array:");
		int num = sc.nextInt();
		int arr[] = new int[num];
		System.out.print("Enter the array elements:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.print("Array before:");
		for(int i =0 ;i<arr.length;i++)
		{
			System.out.println(arr[i]+",");
		}
		System.out.print("Array After:");
		for(int i=arr.length-1;i>=0;i--)
		{
			System.out.print(arr[i]+",");
		}
	}

}
