

import java.util.Scanner;

public class Search_num_into_array {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("please enter the size of array:");
		int num = sc.nextInt();
		int arr[] = new int[num];
		int num1;
		System.out.println("Please enter the element into the array:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.print("Please enter the number which you want to find in the array:");
		num1=sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			if(num1==arr[i])
			{
				System.out.println("Yes number "+num1+" is present at:"+i);
			}
		}
				
	}

}
