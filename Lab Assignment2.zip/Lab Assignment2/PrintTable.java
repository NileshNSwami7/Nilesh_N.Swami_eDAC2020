
import java.util.Scanner;

public class PrintTable {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter the number:");
		int n = sc.nextInt();
		System.out.println("Table:");
		for(int i=1;i<=10;i++)
		{
			int sum = n * i;
			System.out.println("|"+  sum  +"|");
		}
	}

}
