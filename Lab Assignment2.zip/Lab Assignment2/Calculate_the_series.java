

import java.util.Scanner;

public class Calculate_the_series {

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int total=0;
		System.out.print("Eneter the num of the series that is count:");
		int num=sc.nextInt();
		System.out.println("Eneter the starting number of series:");
		int num1=sc.nextInt();
		System.out.print("Series:");
		for(int i=0;i<=num;i++)
		{
			num1+=10;
			System.out.println(num1+",");
			total+=num1;
		}
		System.out.println("Calculation of all the numbers:"+total);
	}

}
