

import java.util.Scanner;

public class BetweenPrimeNumber {

	public static boolean prime(int num)
	{
		for(int i=2;i<num;i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}return true;
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("please enter the first number:");
		int num1 = sc.nextInt();
		System.out.print("Please enter last last number:");
		int num2 = sc.nextInt();
		int count=0;
		System.out.print("Prime number are:");
		for(int i=num1;i<=num2;i++)
		{
			if(prime(i))
			{
				count++;
				System.out.print(+ i +"," );
			}
		}

	}

}
