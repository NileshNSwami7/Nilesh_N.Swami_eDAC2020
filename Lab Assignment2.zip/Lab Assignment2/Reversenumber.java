
import java.util.Scanner;
public class Reversenumber {

	
	public static void main(String[] args) {
		Scanner sc =  new Scanner(System.in);
		System.out.print("Enter the number:");
		long n = sc.nextLong();
		System.out.print("Number After reverse:");
		while(n!=0)
		{
			long result = n%10;
			System.out.print(result);
			n/=10;
		}
	}

}
