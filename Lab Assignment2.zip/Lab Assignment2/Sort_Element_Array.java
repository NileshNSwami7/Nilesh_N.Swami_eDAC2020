
import java.util.Scanner;

public class Sort_Element_Array {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enthe size of array:");
		int num = sc.nextInt();
		System.out.print("please enter the elments into the array:");
		int arr[]= new int[num];
		int arr1[]= new int[num];
		int maxmum=Integer.MAX_VALUE;
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.print("Afrer sort(descending):");
		
		for(int i=0;i<arr.length;i++)
		{
			int temp=0;
			for(int j=0;j<arr.length-i-1;j++)
			{	
				if(arr[j]<=arr[j+1])
				{
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		
		}
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+",");
		}
		System.out.print("Ascending order:");
		for(int j=arr.length-1;;j--)
		{
			System.out.print(arr[j]+",");
		}
	}

}
