

import java.util.Scanner;

public class Even_Odd_Sum_Array {

	public static void main(String[] args) {
		Scanner sc  = new Scanner(System.in);
		int e_sum=0,o_sum=0;
		System.out.println("Please enter the size of array:");
		int num = sc.nextInt();
		int arr[] = new int[num];
		System.out.print("Please enter the element into the array:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = sc.nextInt();
		}
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]%2==0)
			{
				 e_sum+=arr[i];
			}
			else{
				o_sum+=arr[i];
			}
		}
		System.out.println("Sum of even number into the array is:"+e_sum);
		System.out.println("Sum of odd number into the array is:"+o_sum);
	}

}
