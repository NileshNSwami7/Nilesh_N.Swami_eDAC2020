

import java.util.Scanner;

public class Sum_Avg_Array {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter the element into the array:");
		int arr[] = new int[10];
		int res=0;
		double avg=0;
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = sc.nextInt();
		}
		for(int i=0;i<arr.length;i++){
			res=arr[i]+res;
		}
		System.out.println("Sum of array:"+res);
		avg=(double)res/10;
		System.out.println("Average of array:" +avg );
	}

}
