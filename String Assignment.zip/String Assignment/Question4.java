import java.util.Scanner;
class Question4
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter your string without Space");
		String str=sc.next();
		char ch[]=new char[str.length()];
		char ch1[]=new char[str.length()];
		boolean f=true;
		for(int i=0;i<str.length();i++)
		{
			f=true;
			for(int j=0;j<str.length();j++)
			{
				
				if((i!=j) && (str.charAt(i)==str.charAt(j)))
				{
					f=false;
					break;
				}
			}
			if(f)
				{
					System.out.print(str.charAt(i));
				}
		}
		
	}
}