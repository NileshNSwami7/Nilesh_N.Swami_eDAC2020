class Question1
{
	public static void main(String args[])
	{
		String str = "Hello world 37 1!";
		int vowel=0,consonant=0,Number=0,spaces=0,symbol=0;
		str=str.toLowerCase();
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
			{
				vowel++;
			}
			else if((ch>='a' && ch<='z')||(ch>='a' && ch<='z'))
			{
					consonant++;
			}
			else if(ch>='0' && ch<='9')
			{
				Number++;
			}
			else if(ch==' '){
				spaces++;
			}
			else{
				symbol++;
			}
		}
		System.out.println("Vowels: "+vowel);
		System.out.println("Consonant: "+consonant);
		System.out.println("Numbers: "+Number);
		System.out.println("Symbols: "+symbol);
	}
}