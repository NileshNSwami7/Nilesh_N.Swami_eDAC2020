import java.util.Scanner;
class Question5
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		
		String str1[]= str.split("\\s");
		for(int i=0;i<str1.length;i++)
		{
			int j =str1[i].length() ;
			System.out.print(j+" ");
		}
	}
}