import java.util.Scanner;
class Question3
{
	public String removeDuplicate(String str)
	{
		/*String str1=String.valueOf(str);
		
		char ch [] = new char[str1.length()];
		for(int i=0;i<str.length();i++)
		{
			for(int j=0;j<str1.length();j++)
			{
				
				if(str.charAt(i)==str1.charAt(j))
				{
					ch[j]=str.charAt(i);
					break;
				}
			}
		}
		
		String str3 =String.valueOf(ch); //With space 
		
		return noSpace;*/
		
		String rs="";
		
		for(int i=0;i<str.length();i++)
		{
			char ch = str.charAt(i);
			if(ch!=' ')
			{
				rs=rs+ch;
				str=str.replace(ch,' ');
			}
		}
		return rs;
	}
	
	public static void  main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter your string");
		Question3 que = new Question3();
		String str = sc.nextLine();
		
		System.out.println(que.removeDuplicate(str));
	}
}	