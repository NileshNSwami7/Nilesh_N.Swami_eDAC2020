class Question2
{
	public static void main(String args[])
	{
		String str = "There are three bugs and nine features";
		str=str.replace("three","four");
		str=str.replace("nine","ten");
		System.out.println(str);
	}
}