package Assignment4;

import java.util.Scanner;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Please Enter your fraction number:");
		Scanner sc = new Scanner(System.in);
		
		float num = sc.nextFloat();
//		CountFloating fun = new CountFloating();
//		fun.floatFun(num);
		int count=0;
		while(num!=0)
		{
			if(num%10==0)
			{
				count++;
			}
		}
		System.out.println("Floating number:"+count);
		
		
	}

	}


