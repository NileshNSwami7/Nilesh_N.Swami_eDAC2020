package Assignment4;

import java.util.Scanner;

public class SeriesSquar_Cube {

	
	public static void main(String[] args) {
		
		Scanner sc =  new Scanner(System.in);
		System.out.println("Please enter the size of series");
		int n  = sc.nextInt();
		for(int i =1;i<=n;i++)
		{
			if(i%2==0)
			{
				int sum=(int) Math.pow(i,2);
				System.out.print(sum+",");
			}
			else{
				int sum=(int)Math.pow(i,3);
				System.out.print(sum+",");
			}
		}
	}

}
