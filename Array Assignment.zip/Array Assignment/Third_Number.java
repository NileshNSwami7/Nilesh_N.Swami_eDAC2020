package Assignment4;

import java.util.Scanner;
class Third_Number{

public static void main(String[] args)
{
	Scanner sc = new Scanner(System.in);
	System.out.println("Please eneter the size of an array:");
	int num = sc.nextInt();
	int arr[] = new int[num];
	int fsmall=Integer.MIN_VALUE;
	int ssmall=Integer.MIN_VALUE;
	int tsmall=Integer.MIN_VALUE;
	int temp=0;
	System.out.println("Enter the element into array:");
	for(int i=0;i<arr.length;i++)
	{
		arr[i]=sc.nextInt();
	}
	
	for(int j=0;j<arr.length;j++)
	{
		if(fsmall<=arr[j])
		{
			tsmall=ssmall;
			ssmall=fsmall;
			fsmall=arr[j];
		}
		if(ssmall>arr[j])
		{
			tsmall=ssmall;
			ssmall=arr[j];
		}
		if(tsmall>arr[j])
		{
			tsmall=arr[j];
		}
		
	}
	
	System.out.println("f"+fsmall);
	System.out.println("s"+ssmall);
	System.out.println("t"+tsmall);
}
}	
	