package Assignment4;

import java.util.Scanner;

public class MergeArray {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		System.out.println("Enetr the size of array:");
		int size = sc.nextInt();
		int arr[] = new int[size];
		int arr1[] = new int[size];
		int length=0,length1=0,length2=0;
		System.out.println("Array 1:");
		for(int i=0 ; i<arr.length;i++)
		{
			arr[i]= sc.nextInt();
			length++;
		}
		System.out.println("Array 2:");
		for(int j=0;j<arr1.length;j++)
		{
			arr1[j]=sc.nextInt();
			length1++;
		}
		length2=length+ length1;
		int arr2[] = new int[length2];
		int arr3[] =new int [length2];
		int j,k;
		int temp=0;
		for(int i=0;i<arr2.length;i++)
		{
			for(j=0;j<arr.length;j++)
			{
				i++;
				if(i==j)
				{
					arr2[j]=arr[j];
					System.out.println(arr2[j]);
					
				}
				for(k=0;k<arr1.length;k++)
				{
					if(k==j)
					{
						j++;
						arr2[k+j]=arr1[k];
					}
					
				}
			}
		}
	
		for(int i=0;i<arr2.length;i++)
		{
			System.out.print(arr2[i]);
		}
}
}