package Assignment4;

import java.util.Scanner;

public class CountNumber {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter fractional number:");
		double num =sc.nextDouble();
		int count=0;
		while(num!=(int)num)
		{
//			
			count++;
			num=num*10;
		}
		System.out.println(count);
	}

}
