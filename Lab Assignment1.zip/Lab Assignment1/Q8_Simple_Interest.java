

import java.util.Scanner;

public class Q8_Simple_Interest {
	
	public void simpleInterest(double P,double r, int t)
	{
		double A =(double)P*r*t/100;
		System.out.println("Final Amount:"+A);
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter your numbers");
		System.out.println("please enter initial principal balance:");
		
		double P = sc.nextInt();
		System.out.println("please enter annual interest rate:");
		double r =	sc.nextInt();
		System.out.println("Please enter time (in years)");
		int t =	sc.nextInt();
		
		Q8_Simple_Interest SI = new Q8_Simple_Interest();
		SI.simpleInterest(P,r,t);
	}

}
