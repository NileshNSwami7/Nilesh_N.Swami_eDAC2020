

import java.util.Scanner;

public class Q15_Age_Validation {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter your Geter for Male: M/m Female:F/f");
		char ch = sc.next().charAt(0);
		
		if(ch == 'M' || ch=='m')
		{
			System.out.println("Please enter your age:");
			int age = sc.nextInt();
			if(age>=23)
			{
				System.out.println("You are eligible for marraige.");
			}
			else{
				System.out.println("Sorry dear do your study first.");
			}
		}
		else if(ch == 'F' || ch == 'f')
		{
			System.out.println("Please enter your age:");
			int age = sc.nextInt();
			if(age>=21)
			{
				System.out.println("You are eligible for marraige.");
			}
			else{
				System.out.println("Sorry dear do your study first.");
			}
		}
		
	}

}
