

import java.util.Scanner;

public class Q3_Math_Expression {

	public void fun1(int x)
	{
		int y=(int)((Math.pow(x, 2))+3*x-7);
		System.out.println("Value of y:"+y);
	}
	public void fun2(int x)
	{
		int y = x++ + ++x;
		System.out.println("Value of x:"+ x +" value of y:"+y);
	}
	public void fun3(int x,int y)
	{
		int z = x++ - --y - --x  +  x++ ;
		System.out.println("Value of x: " + x + " Value of y: " + y + " value of z: "+z);
	}
	public void fun4(boolean x,boolean y)
	{
		boolean z = x && y || !(x || y);
		System.out.println("Value of x: "+x+" value of y: "+y+" value of z "+z );
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the value X & Y");
		int x = sc.nextInt();
		int y = sc.nextInt();
		System.out.println("Please enter the boolean value:");
		System.out.print("value of x:");
		boolean x1;
		System.out.printf("\n",x1 =sc.nextBoolean());
		System.out.print("value of y:");
		boolean y1;
		System.out.printf("value of y:", y1 =sc.nextBoolean());
		Q3_Math_Expression ME = new Q3_Math_Expression();
		ME.fun1(x);
		ME.fun2(x);
		ME.fun3(x,y);
		ME.fun4(x1, x1);
	}

}
