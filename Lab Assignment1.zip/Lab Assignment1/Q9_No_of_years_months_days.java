

import java.util.Scanner;

public class Q9_No_of_years_months_days {

	public void year(int days)
	{
		int y=days/365;
			days%=365;
		System.out.println("Year:"+y);
		
		int month=days/30;
			days%=30;
		System.out.println("Month:"+month);
		
		int d =days/7;
			days%=7;
		System.out.println("Week:"+d);
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the number of days:");
		int days = sc.nextInt();
		
		Q9_No_of_years_months_days YMD = new Q9_No_of_years_months_days();
		
		YMD.year(days);
	}

}
