

import java.util.Scanner;

public class Q10_Temperature {

	public void calTemperature(double f)
	{
		float c = (float)( 5*(f-32)/9);
		System.out.println("Temperature in celcious:"+c+" c");
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the temperature in form of Fahrenheit:");
		double f = sc.nextDouble();
		
		Q10_Temperature temp = new Q10_Temperature();
		temp.calTemperature(f);
	}

}
