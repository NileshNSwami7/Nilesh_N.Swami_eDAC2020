

import java.util.Scanner;

public class Q4_Byte_Variables {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the value:");
		int b = sc.nextInt();
		byte b1 =(byte)b;
		System.out.println("value of byte:"+b1);
	}

}
