

import java.util.Scanner;

public class Q6_AreaOf_Circle {

	public void areaofCircle(float r)
	{
		float area =3.14f * r*r;
		System.out.println("Area of Circle:"+area);
	}
	public void circumferenceof_Circle(float r)
	{
		float circumference= 2*3.14f*r;
		System.out.println("Circumference of circle:" +circumference);
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the radius:");
		
		float r = sc.nextFloat();
		Q6_AreaOf_Circle AC = new Q6_AreaOf_Circle();
		AC.areaofCircle(r);
		AC.circumferenceof_Circle(r); 
	}

}
