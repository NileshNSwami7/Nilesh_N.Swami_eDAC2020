

import java.util.Scanner;

public class Q11_Swap_number_ {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter two value for swamiping");
		int num = sc.nextInt();
		int num1 = sc.nextInt();
		System.out.println("Before swapping num:"+num+" num1:"+num1);
		 if(num<=num1)
		 {
			 num1=num1-num;
			 num=num1+num;
			 System.out.println("After swapping num:"+num+" num1:"+num1);
		 }
		 else if(num>=num1)
		 {
			 num=num-num1;
			 num1=num+num1;
			 System.out.println("After swapping num:"+num+" num1:"+num1);
		 }
	}

}
