

import java.util.Scanner;

public class Hello_World {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your String:");
		String str = sc.nextLine();
		System.out.println(str);
	}

}
