

import java.util.Scanner;

public class Q7_Percentage {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int sum=0;
		System.out.println("How many subject:");
		int no_of_sub=sc.nextInt();
		System.out.println("Please enter your marks");
		for(int i=0;i<no_of_sub;i++)
		{
			System.out.println("Enter the marks of Subject "+i+" : ");
			int marks = sc.nextInt();
			sum+=marks;
		}
		float total = (float)(sum/no_of_sub);
		System.out.println("Your percentage: "+total+" %");
		
	}

}
