

import java.util.Scanner;

public class Q13_greatest_number {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the three numbers:");
		int num = sc.nextInt();
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		
		if(num>=num1)
		{
			System.out.println("Num1 is greatest that is:" +num);
		}
		else if(num1>=num2)
		{
			System.out.println("Num2 is greatest that is:" +num1);
		}
		else if(num2>=num)
		{
			System.out.println("Num3 is greatest that is:" +num2);
		}
		
		/*Ternery Operator*/
		
		int GrtNum = (num>=num1)? num:((num1>=num2)? num1:num2);
		System.out.println("Greatest number:"+GrtNum);
	}

}

