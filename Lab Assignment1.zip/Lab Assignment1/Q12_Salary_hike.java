

import java.util.Scanner;

public class Q12_Salary_hike {

	
	public void GS(double rs,double BS)
	{
		double GS = BS+rs;
		System.out.println("Gross Salary:"+GS);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter your salary");
		double rs = sc.nextDouble();
		Q12_Salary_hike sal = new Q12_Salary_hike();
		if(rs<10000)
		{
			double BS =(rs/10)+ (rs/90);
			System.out.println("BS: "+BS+"rs");
			sal.GS(rs,BS);
		}
		else if(rs>=1000)
		{
			double BS = 2000+(rs/98);
			System.out.println("BS:"+BS+"rs");
			sal.GS(rs,BS);
		}
	}

}
