

import java.util.Scanner;

public class Q2_Print_Num {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number:");
		int num = sc.nextInt();
		System.out.println("Roll no = "+num);
	}

}
