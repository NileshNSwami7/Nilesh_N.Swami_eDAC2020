//Faculty with two data members facultyId and�salary and two methods, one intput() method for accepting facultyId as input and another printSalary() to print salary.

import java.util.Scanner;
class Faculty
{
	int facultyId;
	double salary;
		
	
	public void input()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter facultyID");
		int facultyId=sc.nextInt();
	}
	
	public void printSalary(double salary)
	{
		System.out.println("Salary"+salary);
	}
}
//FullTimeFaculty�that inherits�class�Faculty with two data members� basicSalary and�allowance. Override input() method in this class that calls super class inut() method and accepts basicSalary and allowance as input. Salary should not be accepted as input but should be calculated using formula (basicSalary + allowance)

class FullTimeFaculty extends Faculty
{
	double basicSalary;
	double allowance;

	FullTimeFaculty(double sal,double all)
	{
		this.basicSalary=sal;
		this.allowance=all;
	}	

	double total;
	public void input()
	{
		super.input();
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter basic salary:");
		basicSalary=sc.nextDouble();
		System.out.println("Enter allowance:");
		allowance=sc.nextDouble();
		total=basicSalary+allowance;
		super.printSalary(total);
	}
}
//PartTimeFaculty that�inherits�class�Faculty�with two data members� workingHours,�ratePerHour. Override input() method in this class that calls super class inut() method and accepts workingHours and ratePerHour as input. Salary should not be accepted as input but should be calculated using formula ( workingHour * ratePerHour )

class PartTimeFaculty extends Faculty
{
	double workingHours;
	double ratePerHour;

	public void input()
	{
		super.input();
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter working hours:");
		workingHours=sc.nextDouble();
		System.out.println("Enter ratePerHour:");
		ratePerHour=sc.nextDouble();
		double total1=workingHours*ratePerHour;
		super.printSalary(total1);
	}
}
class StaffDemo
{
	public static void main(String args[])
	{
		
		Faculty f1 = new Faculty();
		
		FullTimeFaculty f2 = new FullTimeFaculty();

		PartTimeFaculty f3 = new PartTimeFaculty();
	
		f2.input();
		f3.input();	
	}
}