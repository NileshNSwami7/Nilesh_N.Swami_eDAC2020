class OneBHK
{
	double roomArea;
	double hallArea;
	double price;
	// Create a class OneBHK with instance variables roomArea, hallArea and price. Then create default constructor that initializes instance variables with some values 
	OneBHK()
	{
		 roomArea= 35.00;
		 hallArea= 50.00;
		 price=2500000;
	}

	//and a parameterized constructor that takes values for all instance variables and stores them in instance variables. 

	OneBHK(double roomArea,double hallArea,double price)
	{
		this.roomArea = roomArea;
		this.hallArea = hallArea;
		this.price = price;
	}
	//Now create a method named show() 

	void show()
	{
		System.out.println("RoomArea: "+roomArea+" HallArea: "+hallArea+" Price: "+price);
	}
}
	
class TwoBHK extends OneBHK
{
	double room2Area;
	
	TwoBHK(double roomArea,double hallArea,double price)
	{
		super(roomArea,hallArea,price);
		this.room2Area = room2Area;
	}
	
	void show()
	{
		System.out.println("RoomArea: "+roomArea+" HallArea: "+hallArea+" Price: "+price+" Room2Area: "+room2Area);
	}
}
class Demo
{
	public static void main(String args[])
	{
	     //to print OneBHK�s instance variable values.
	
		OneBHK bhk = new OneBHK();
		TwoBHK tbhk = new TwoBHK(30.00);
		bhk.show();
		tbhk.show();
	}
}