//Create a class MathOperation that has four static methods. add() method that takes two integer numbers as parameter and returns the sum of the numbers. subtract() method that takes two integer numbers as parameter and returns the difference of the numbers. multiply() method that takes two integer numbers as parameter and returns the product. power() method that takes two integer numbers as parameter and returns the power of first number to second number. Create another class Demo (main class) that takes the two numbers from the user and calls all four methods of MathOperation class by providing entered numbers and prints the return values of every method.


import java.util.*;
import java.lang.Math;
class MathOperation
{
	
	public static int Add(int n1, int n2)
	{
		int sum = n1+n2;
		return sum;
	}
	
	public static int sub(int n1,int n2)
	{
		int difference = n1- n2;
		return difference;
	}
	
	public static int multiply(int n1,int n2)
	{
		int product = n1*n2;
		return product;
	}
	
	public static int power(int n1,int n2)
	{
		int power1 = (int)Math.pow (n1,n2);
	
		return power1;		
	}
}
class Demo
{
	public static void main(String args[])
	{
		MathOperation m = new MathOperation();
		System.out.println("Add: "+m.Add(2,2));
		System.out.println("Difference: "+m.sub(3,1));
		System.out.println("Multiply: "+m.multiply(4,5));
		System.out.println("Power: "+m.power(2,3));
	}
}		
		