class Student 
{
	int rollno;
	String name;
	
	public void setData(int rollno,String name)
	{
		this.rollno = rollno;
		this.name=name;
	}
	
	public void showData()
	{
		System.out.println("rollno: "+rollno+" name: "+name);
	}
}
class StudentDemo
{
 	public static void main(String args[])
	{
		Student st = new Student();
		st.setData(016,"Nilesh");
		st.showData();
	}
}	