import java.util.Scanner;
class Employee 
{
	long empNo;
	double salary;
	double totalSalary;
	int count=0;
	Employee (long no , double sal , double tsal)
	{
		this.empNo = no;
		this.salary = sal;
		this.totalSalary = tsal;

	}
	
	public void totalSalary()
	{
	
		System.out.println("No of Employee: "+empNo+" salry:"+salary+" TSal: "+totalSalary);
	}
	

}
class EmployeeDemo
{

	public static void main(String args[])
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter no.of employee:");
		int e=sc.nextInt();
		System.out.println("Add your data.");
		System.out.println("Enter 1st empNo.:");
		long number;
		number =sc.nextLong();
		for(int i=0;i<e;i++)
		{	
			System.out.println("Enter the salary:");
			double sal = sc.nextDouble();
			System.out.println("Total salary:");
			double tsal = sc.nextDouble();
			Employee demo = new Employee (number,sal,tsal);	
			number++;
			demo.totalSalary();
		}
	}
}

		