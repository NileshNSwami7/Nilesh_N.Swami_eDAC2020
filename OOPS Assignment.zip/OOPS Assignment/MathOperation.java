//Create a class MathOperation containing overloaded methods �multiply� to calculate multiplication of following arguments. 
 two integers 
 three floats 
 all elements of array 
one double and one integer 


class MathOperation
{
	public void multiply(int num1,int num2)
	{
		int num3=num1 * num2;
		System.out.println("Multiply int variable: "+num3);
	}
	
	public void multiply(float num,float num1,float num2)
	{
		float f1 = num * num1 * num2;
		System.out.println("Multiply float variable:"+f1);
	}
	
	public void multiply(int arr[])
	{
		System.out.println("Multiply Array:");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+",");
		}
		System.out.println();
	}
	public void multiply(double num1 , int num3)
	{
		double d1 = num1*(double)num1;
		System.out.println("Double multiply:"+d1);
	}

public static void main(String args[])
{
	MathOperation MO = new MathOperation();
	int arr[]={2,5,6,7,4};
	MO.multiply(2,2);
	MO.multiply(2.2f,3.4f,5.4f);
	MO.multiply(arr);
	MO.multiply(3.54,2);
}
}