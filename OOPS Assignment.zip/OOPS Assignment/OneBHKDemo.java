class OneBHK
{
	double roomArea;
	double hallArea;
	double price;

	// Create a class OneBHK with instance variables roomArea, hallArea and price. Then create default constructor that initializes instance variables with some values 
	OneBHK()
	{
		 roomArea= 35.00;
		 hallArea= 50.00;
		 price=2500000;
	}

	//and a parameterized constructor that takes values for all instance variables and stores them in instance variables. 

	OneBHK(double roomArea,double hallArea,double price)
	{
		this.roomArea = roomArea;
		this.hallArea = hallArea;
		this.price = price;
	}

	//Now create a method named show() 

	void show()
	{
		System.out.println("RoomArea: "+roomArea+" HallArea: "+hallArea+" Price: "+price);
	}
}

//Create another class TwoBHK which has (inherits) all the properties and behaviors of OneBHK and a new instance variable room2Area
	
class TwoBHK extends OneBHK
{
	double room2Area;
	
	TwoBHK()
	{
		super();
		this.room2Area = 30.00;
	}

//Then create default constructor to initialize all 4 instance variables and a parameterized constructor to take the values for initialization of all instance variables.
 
	TwoBHK(double roomArea,double hallArea,double price,double room2Area)
	{
		super(roomArea,hallArea,price);
		this.room2Area=room2Area;

	}

//Override show() method to print all data member information.

	void show()
	{
		System.out.println("RoomArea: "+roomArea+" HallArea: "+hallArea+" Price: "+price+" Room2Area: "+room2Area);
	}
}
class Demo
{
	public static void main(String args[])
	{
	     //to print OneBHK�s instance variable values.
	
		OneBHK bhk = new OneBHK();
		TwoBHK tbhk = new TwoBHK();
		bhk.show();
		tbhk.show();
		TwoBHK t[] = new TwoBHK[3];
		
//Write main method in another class (Say Demo) and store three TwoBHK flat�s information and print information using show method. 

		t[0]= new TwoBHK(25.00,50.00,3000000,30.00);
		t[1]= new TwoBHK(25.00,55.00,4000000,35.00);
		t[2]= new TwoBHK(30.00,60.00,5500000,35.00);

//Also print total amount of all flats. 

		double sum=0;
		for(int i=0;i<t.length;i++)
		{
			t[i].show();
			sum+=t[i].price;			
		}
		System.out.println("Total Amount of all flats: "+(long)sum);
	}
}