import java.util.Scanner;
class Product
{
	 int pid;
	 double price;
	 int quantity;
	
	Product(int pid,double price,int quantity)
	{
		this.pid=pid;
		this.price=price;
		this.quantity=quantity;
	}
	
		
	public void display()
	{
	System.out.println("Pid: "+pid+ " Price: " +price+ " Quantity "+ quantity);	
	}
	
	public static double Amount(double price,int quantity)
	{
		
			double amount =price * quantity;
			return amount;
	}

	
}
class ProductDemo
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int pid=0;
		double price=0;
		int quantity=0;
		System.out.println("Please enter no. of Products:");
		int size = sc.nextInt();
		Product p[] =  new Product[size];	
		//Product p1 = new Product();	
		double pr[]=new double[size];
	
	// . Accept information for five Product objects from user and store objects in an array.
		

		for(int i=0;i<p.length;i++)
		{
			System.out.println("enter PID:");
			pid=sc.nextInt();
			System.out.println("Add price");
			price=sc.nextDouble();
			
			 pr[i] =price;
			System.out.println("Add Quantity:");
			quantity=sc.nextInt();
			
			p[i] = new Product(pid,price,quantity);	
		}
		
		for(int i=0;i<p.length;i++) 
		{
			p[i].display();
				
		}
		
		// b. Find pid of product with highest price. 

		double max = Double.MIN_VALUE;
		for(int i=0;i<p.length;i++)
		{
			double temp=0;
			
			if(max<=pr[i])
			{
				temp=max;
				max=pr[i];	
			}
		}
		for(int i=0;i<p.length;i++)
		{
			if(max==p[i].price)
				{
					System.out.println("PID: "+p[i].pid+"Max Price: "+max);
				}
		}		

		// Create a static method (with array of product�s object as argument) in Product class to calculate and return total amount spent on all products. ( amount spent on single product = price of product * quantity of product )

		for(int i=0;i<p.length;i++)
		{
			System.out.println("Amount of Product:"+p[i].Amount(p[i].price,p[i].quantity));
		}

	}
}	

		