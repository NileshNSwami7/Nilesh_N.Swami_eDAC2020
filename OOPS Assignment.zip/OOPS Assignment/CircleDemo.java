
import java.util.Scanner;

//Create a class Circle that has two data members, one to store the radius and another to store area

class Circle
{
	double radius;
	double area;
	

//three methods first init() method to input radius from user, second calculateArea() method to calculate area of circle and third display() method to display values of radius and area


	public void init(double r)
	{
		radius=r;
	}	
	public void calculateArea()
	{
		area =3.14*radius*radius;
	}
	public void display()
	{
		System.out.println("Area of circle: "+area);
	}
}

//Create class CircleDemo ( main class) that creates the Circle object and calls init(), calculateArea() and display() methods.

class CircleDemo
{
	 public static void main(String args[])
	{
		
		Circle c = new Circle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the radius:");
		double radius = sc.nextDouble();
		c.init(radius);
		c.calculateArea();
		c.display();
	}
}