import java.util.Scanner;
abstract class Processor
{
	int member;
	

	void showData(int member)
	{
	}
 
	abstract void process();
}
class Factorial extends Processor
{
	
	void process()
	{	int sum=1;
		Scanner sc = new Scanner(System.in);
		System.out.println("Please Enter Number:");
		int num=sc.nextInt();
		for(int i=num;i>1;i--)
		{
			sum*=i;
		}
		System.out.println("Factorial is: "+sum);
	}
}
class Circle extends Processor
{
	void process()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please Enter Area:");
		int radius=sc.nextInt();
		double Area = 3.14 * radius * radius;
		System.out.println("Area of Circle: "+Area);
	}
}	
class Choice
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		Processor p = new Factorial();
		Processor p1 = new Circle();
		System.out.println("Please select one choice A:Processor and B : Area of circle:");	
		char ch = sc.nextLine().charAt(0);
		
		switch(ch)
		{
			case 'A' : p.process();
				break;
			case 'B' : p1.process();
				break;
			default:
		}
	}

}