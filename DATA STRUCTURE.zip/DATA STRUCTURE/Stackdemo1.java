import java.util.Scanner;
import java.util.Scanner;
class StackDemo1
{
	int capacity;
	int stack[]=null;
	int top=-1;
	
	public StackDemo1(int capacity)
	{
		this.capacity=capacity;
		stack=new int[capacity];
	}
	 public void  push(int ele[])
	 {
		 if(isFull())
		 {
			 System.out.println("Stack is Underflow");
			 return ;
		 }
		 else
		 {
			 for(int i=0;i<ele.length;i++)
			 {
				stack[++top]=ele[i];
			 }
			 Scanner sc = new Scanner(System.in);
			 System.out.println("Do you want to see the Stack element Yes:Y/No:N");
			 char ch = sc.next().charAt(0);
			 if(ch=='Y'||ch=='y')
			 {
				 for(int j=0;j<ele.length;j++)
				 {
					 System.out.println(stack[top--]);
				 }
			 }
			 else
			 {
				 break;
			 }
		 }
	 }
	 public void Pop()
	 {
		 if(top==-1)
		 {
			 System.out.println("Stack is empty");
			 return;
		 }
		 else
		 {
			 
			 int ele1=stack[top--];
			 System.out.println("Pop this element:"+ele1);
		 }
	 }
	 
	 public boolean isEmpty()
	 {
			 return top==-1;
	 }
	 
	 public boolean isFull()
	 {
		 return (top+1)== capacity;
	 }
	 
	 public int peek()
	 {
		 if(isEmpty())
		 {
			 return -1;
		 }
		 return stack[top];
	 }
	 
	 public int size()
	 {
		 return top+1;
	 }
	 
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the size of stack");
		int num = sc.nextInt();
		StackDemo1 SD = new StackDemo1(num);
		char ch;
		do
		{
			System.out.println("Please select one function to do operation");
			System.out.println("1.push");
			System.out.println("2.pop");
	 		System.out.println("3.isEmpty");
			System.out.println("4.isFull");
			System.out.println("5.peek");
			System.out.println("6.Size");
			
			int n=0;
			int number = sc.nextInt();
			int arr[] =new int[num];
			switch(number)
			{
				case 1:{
							System.out.println("Please Add the element");
							for(int i=0;i<arr.length;i++)
							{
								arr[i]=sc.nextInt();
								
							}
							System.out.println("You have added all elements successfully.");
							SD.push(arr);
						}
						break;
				case 2 :{
							System.out.println("poping elements");
							for(int i=0;i<num;i++)
							{
								SD.Pop();
							}
						}
						break;
				case 3 :{
							System.out.println("IS your Stack is empty: "+SD.isEmpty());
						}
						break;
				case 4 :{
						    System.out.println("IS your Stack is Full: "+SD.isFull());
						}
						break;
				case 5 :{
							System.out.println("The peek element will be: "+SD.peek());
						}
						break;
				case 6 :{
							System.out.println("Size of Stack: "+ SD.size());
						
						}break;
						
				default :{
							System.out.println("Default");
						}
				}
				System.out.println("Select y/n");
				
				ch = sc.next().charAt(0);
			}
			while(ch=='Y'|| ch=='y');
	}

}