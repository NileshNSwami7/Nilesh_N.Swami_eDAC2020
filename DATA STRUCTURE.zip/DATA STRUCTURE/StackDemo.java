class StackDemo
{
	static int stack[],top=-1;
	 int isPush(int ele)
	{
		if(isFull(int ele))
		{
			return 1;
		}
		else
		{
			 top++;
			 stack[top] = ele;
			 System.out.println("push element"+ele);
			
		}
		return 0;
	}
	int isFull(int ele)
	{
		if(top==ele-1)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	int pop(int ele)
	{
		if(isEmpty())
		{
			System.out.pritnln("Stack is underflow.");
		}
		else{
			return stack[top--];
				return 0 ;
		}
	}
	int isEmpty(int ele)
	{
		if(top==-1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	void peek(int ele)
	{
		if(isEmpty())
		{
			System.out.println("Stack is empty");
		}
		else{
		System.out.println("peek an element:"+stack[ele]);
		}
	}
	
	 void traverse(int ele)
	{
		if(isEmpty())
		{
			System.out.println("Stack is underflow.");
		}
		else{
				for(int i=0;i<top;i++)
				{
				System.out.println(stack[top]);
				}
			}		
	}
	public static void main (String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		StackDemo SD = new StackDemo();
		do 
		{
			System.out.println("Please enter size of stack");
			int num = sc.nextInt();
			int Stack[] = new Int[num];
			
			System.out.println("please enter your choice:");
			
			System.out.println("1:Push");
			System.out.println("2:Pop");
			System.out.println("3:Peek");
			System.out.println("4:Traverse");
			System.out.println("5:exit");
			
			char ch ;
			int ele;
			int number=sc.nextInt();
			
			switch(ch)
			{
				case 1:{ 
							System.out.println("Please enter the number.");
							ele=sc.nextInt();
							System.out.println(SD.isPush(ele));}
						break;
				case 2: {
							System.out.println(SD.isPop());
							if(iteam==0)
							{
							System.out.println(SD.isFull());
							}
							else{
							System.out.println("popped item:+ele");
							}
						
						}
						break;
				case 3: {System.out.println(isPush());}
						break;
				case 4: {System.out.println(isPush());}
						break;
						
				case 6: {
							System.out.println(is.Traverse());
							break;
						}
				
				case 5: exit(0);
				
				
				default:System.out.println("invalid entry sorry");
			}
			System.out.println("Do you wan to continue the operation Y/N");
				ch=sc.next().charAt(0);
		}
			while(ch=='Y'||ch=='y');
						System.out.println("Thank you i hope you will enjoy this operation..!");
	}
}	