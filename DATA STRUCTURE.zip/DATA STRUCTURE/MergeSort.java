import java.util.*;
class MergeSort
{
	int array[];
	int temparr[]; 
	public void value(int arr[])
	{
		this.array=arr;
		this.temparr=new int[array.length];
		MSort(0,temparr.length-1);
	}
	public void MSort(int start,int length)
	{
		if(start<length)
		{
			int mid =start+(length-start)/2;
			MSort(start,mid);//left
			MSort(mid+1,length);//right
			MergeArray(start,mid,length);
		}
	}
	public void MergeArray(int start,int mid,int length)
	{
		for(int i=start;i<=length;i++)
		{
			temparr[i]=array[i];
		}
		int i=start;
		int j=mid+1;
		int k=start;
		for(;i<=mid && j<=length;)
		{
			if(temparr[i]<=temparr[j])
			{
				array[k]=temparr[i];
				i++;
			}
			else
			{
				array[k]=temparr[j];
				j++;
			}
			k++;
		}
			while(i<=mid)
			{
				array[k]=temparr[i];
				k++;
				i++;
			}
				
	}		
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		MergeSort MS = new MergeSort();
		int n = sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		MS.value(arr);
		for(int i=0;i<arr.length;i++)
		{
			System.out.print (arr[i]+" ");
		}
	}
}