import java.util.*;
class QuickSort
{
	
	public void quickSort(int arr[],int start,int end)
	{
		int pivot = sort(arr,start,end);
		if(start<pivot-1)
		{
			quickSort(arr,start,pivot-1);
		}
		if(pivot<end)
		{
			quickSort(arr,pivot,end);
		}
	}
	public int sort(int arr[],int start,int end)
	{
		int pi=arr[(start+end)/2];
		while(start<=end)
		{
			while(arr[start]<pi)
			{
				start++;
			}
			while(arr[end]>pi)
			{
				end--;
			}
			if(start<=end)
			{
				int temp=arr[start];
				arr[start]=arr[end];
				arr[end]=temp;
			}
		}
		return start;
	}
	public void printArray(int arr[])
	{
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enete the size of array.");
		int n = sc.nextInt();
		int arr[] = new int[n];
		QuickSort QS = new QuickSort();
		System.out.println("Please enter the elements");
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		QS.quickSort(arr,0,n-1	);
		QS.printArray(arr);
	}
}
		