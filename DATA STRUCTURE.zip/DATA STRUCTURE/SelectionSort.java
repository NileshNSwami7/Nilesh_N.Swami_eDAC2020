import java.util.Scanner;

public class SelectionSort {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[10];
		int num;
		int min;
		int temp=0;
		Scanner ip=new Scanner(System.in);
		System.out.println("Enter the elements:");
		for(int i=0;i<arr.length;i++)
		{
			num=ip.nextInt();
			arr[i]=num;
		}
		for(int i=0;i<arr.length;i++)
		{
			min=i;
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[j]<arr[min])
				{
					min=j;
				}
			}
			temp=arr[i];
			arr[i]=arr[min];
			arr[min]=temp;
		}
		System.out.println("After Selection sort:");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(" "+arr[i]);
		}
	}

}
