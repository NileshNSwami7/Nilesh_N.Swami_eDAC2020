import java.util.*;
public class CircularDemo
{
	int capacity;
	int Cqueue[]=null;
	int rear=-1;
	int front=-1;
	int size=0;
	
	CircularDemo(int capacity)
	{
		this.capacity = capacity;
		Cqueue = new int[capacity];
	}
	
	public void enqueue(int ele[])
	{
		for(int i=0;i<ele.length;i++)
		{
			if(isFull())
			{
				System.out.println("enqueue is cant insert");
				return ;
			}
			
			rear = rear+1;
			if(rear==capacity)
			{
				rear=0;
			}
			Cqueue[rear]= ele[i];
			size++;
			System.out.println("Elements are successfully."+ele[i]);
			System.out.println("rear Element is:"+ele[i]);

		}
	}
	public  void dequeue()
	{
		
			if(isEmpty())
			{
				System.out.println("Queue is empty");
				return;
			}
		    int ele=Cqueue[front];
			front=(front+1)%capacity;
			size--;
			System.out.println("Elements are dequeue successfully."+ele);
			System.out.println("rear Element dequeue is:"+ele);

		
	}
	
	public  boolean isFull()
	{
		return size() == capacity;
	}
	public boolean isEmpty()
	{
		return size == 0;
	}
	public int size()
	{
		return size;
	}
	public int rear()
	{
		if(isEmpty())
		{
			System.out.println("Queue is Empty");
			return Integer.MIN_VALUE;
		}
		return Cqueue[rear];
	}
	public int front()
	{
		if(isEmpty())
		{
			System.out.println("Queue is Empty");
			return Integer.MIN_VALUE;
		}
		return Cqueue[front];
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Please enter the capacity of circular queue");
		int num = sc.nextInt();
	
		CircularDemo CD = new CircularDemo(num);
		
		char ch;
		
		do
		{
			System.out.println("Please enter your choice:");
			System.out.println("1.enqueue.");
			System.out.println("2.dequeue.");
			System.out.println("3.size.");
			System.out.println("4.rear.");
			System.out.println("5.front.");
			
			int n = sc.nextInt();
			int arr[] = new int[num];
			switch(n)
			{
				case 1: {
							System.out.println("enter the elements:");
							for(int i=0;i<num;i++)
							{
								arr[i]=sc.nextInt();
							}
							CD.enqueue(arr);
						}break;
			   case 2: {
							System.out.println("Dequeue all the elements:");
							for(int i=0;i<num;i++)
							{
								CD.dequeue();
							}
						}break;
						
				case 3:{
							System.out.println("Size of queue is :"+CD.size());
							CD.size();
						}break;
						
				case 4:{
							System.out.println("Rear of queue is :"+CD.rear());
							
						}break;
				case 5:{
							System.out.println("Front of queue is :"+CD.front());
							
						}break;
				
				default: {
							System.out.println("Wrong entry");
						 }
				}
				System.out.println("Do you want to continue the operation if select option y/n");
				ch=sc.next().charAt(0);
		}while(ch=='y'|| ch=='Y');
	}
}