class ParenthesisChecking
{
	
	static class stack
	{
		int top=-1;
		char item[]=new char[100];
		
		void push(char x)
		{
			if(top==99)
			{
				System.out.println("stack full");
			}
			else{
				item[++top]=x;
			}
		}
		char pop()
		{
			if(top==-1)
			{
				System.out.println("Underflow error");
				return '\0';
			}
			else{
				char element =item[top];
				top--;
				return element;
			}
		}
		boolean isEmpty()
		{
			return (top==-1)?true:false;
		}
	}
	static boolean isMatchingPair(char ch1,char ch2)
	{
		if(ch1=='(' &&ch2==')')
			return true;
		else if(ch1=='{' && ch2=='}')
			return true;
		else if(ch1=='[' && ch2==']')
			return true;
		else
			return false;
	}
	
	static boolean areParenthesisBalanced(char exp[])
	{
		stack st = new stack();
		for(int i=0;i<exp.length;i++)
		{
			if(exp[i]=='{'||exp[i]=='('||exp[i]=='[')
				{
					st.push(exp[i]);
				}
			if(exp[i]=='}'||exp[i]==')'||exp[i]==']')
			{
				if(st.isEmpty())   /*if we see an ending parenthesis without a pair then return false*/
				{
					return false;
				}
				else if(!isMatchingPair(st.pop(),exp[i]))
				{
					return false;
				}
			}
		} /*if there is something left in expression then there is staring parenthesis thesis without closing parenthesis*/
		if(st.isEmpty())
		{
			return true;//balance
		}
		else 
		{
			return false;
		}
	}
	
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		Parenthesis
		Sysem.out.println("Please enter the parenthesis");
		char ch=sc.next.charAt(0);
		
		switch(ch)
		{
			case '{':{
						
		char exp[]={'{','(',')','}','[',']'};
		
		if(areParenthesisBalanced(exp))
		{
			System.out.println("Balanced");
		}
		else
		{
			System.out.println("Not Balnaced");
		}
	}	
}