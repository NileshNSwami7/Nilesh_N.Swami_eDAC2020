import java.util.*;
class DoublyLL
{
	Node head;
	Node tail;
	int length;
	Node start;
	class Node
	{
		int data;
		Node next;
		Node prev;
		
		Node(int data)
		{
		 this.data=data;
		 }
	}
	public DoublyLL()
	{
		this.head=null;
		this.tail=null;
		this.start=null;
		int length=0;
	}
	
	public boolean isEmpty()
	{
		return length==0;
	}
	public int length()
	{
		return length=0;
	}
	public void CreateLikedList(int value[])
	{
		
		for(int i=0;i<value.length;i++)
		{
			Node newNode = new Node(value[i]);
			
			if(isEmpty())
			{
				tail = newNode;
			}
			else{
				head.prev = newNode;
			}
			newNode.next=head;
			head = newNode;
			length++;
		}
	}
	
	public void insertFirst(int number)
	{
			Node newNode = new Node(number);
			
			if(isEmpty())
			{
				tail = newNode;
			}
			else{
				head.prev = newNode;
			}
			newNode.next=head;
			head = newNode;
			length++;
		
	}
	public void inBetween(int pos,int n3)
	{
		if(pos==1)
		{
			insertFirst(n3);
		}
		else if(pos>length)
		{
			insertLast(n3);
		}
		else
		{
			int i=1;
			Node nNode = head;
			while(nNode.next!=null)
			{
				i++;
				if(i==pos)
					break;
				nNode=nNode.next;
			}
			Node newNode = new Node(n3);
			newNode.prev=nNode;
			newNode.next=nNode.next;
			nNode.next.prev=newNode;
			nNode.next=newNode;
			length++;
		}
	}
	
	public void insertLast(int value)
	{
		
			Node newNode = new Node(value);
			if(isEmpty())
			{
				head=newNode;
			}
			else
			{
				tail.next = newNode;
			}
			newNode.prev = tail;
			tail = newNode;
			length++;
		
	}
	public void displayForward()
	{
		if(head==null)
		{
			return;
		}
		Node temp = head;
		while(temp!=null)
		{
			System.out.print("["+temp.data+"]"+"->");
			temp=temp.next;
		}
		System.out.println("null");
	}
	public void displayBackward()
	{
		if(tail == null)
		{
			return;
		}
		Node temp =  tail;
		while(temp!=null)
		{
			System.out.print("["+temp.data+"]"+"->");
			temp=temp.prev;
		}
		System.out.println("null");
	}
 	public Node deleteFirst()
	{
		if(isEmpty())
		{
			throw new NoSuchElementException();
		}
		Node temp = head;
		if(head==tail)
		{
			tail=null;
		}
		else{
			head.next.prev = null;
		}
		head = head.next;
		temp.next = null;
		length--;
		return temp;
	}
	public Node deleteLast()
	{
		if(isEmpty())
		{
			throw new NoSuchElementException();
		}
		Node temp = tail;
		if(head==tail)
		{
			head=null;
		}
		else
		{
			tail.prev.next=null;
		}
		tail=tail.prev;
		temp.prev=null;
		return temp;
	}
	public Node deletePosition(Node head,int pos)
	{
		if(head==null)
		{
			return head;
		}
		if(pos==1)
		{
			if(head.next!=null)
			{
				head.next.prev=null;
			}return head.next;
		}
		Node node = head;
		while(node!=null && pos>1)
		{
			node=node.next;
			pos--;
		}
		if(node==null)
		{
			System.out.println("Element does not exist.");
			return head;
		}
		if(node.next!=null)
		{
			node.next.prev=node.prev;
		}
		node.prev.next=node.next;
		return head;
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the size of your DoublyLinkedList:");
		int num = sc.nextInt();
		DoublyLL dll = new DoublyLL();
		char ch;
		
		do
		{
			System.out.println("Please enter the option :");
			System.out.println("0.Create LinkedList first:");
			System.out.println("1.Insert at First:");
			System.out.println("2.Insert at Last:");
			System.out.println("3.Insert in Between.:");
			System.out.println("4.Forward Direction");
			System.out.println("5.Backward LinkedList");
			System.out.println("6.Delete 1st Node.:");
			System.out.println("7.Delete last Node:");
			System.out.println("8.Delete the Node position wise.:");
			
			int n1 = sc.nextInt();
			int arr[] = new int[num];
			int arr1[]=null;
			switch (n1)
			{
		
				case 0 :{
							System.out.println("Please enter the element at first.:");
							for(int i=0;i<arr.length;i++)
							{
								arr[i]=sc.nextInt();
							}
							dll.CreateLikedList(arr);
						}break;
				case 1:{
							System.out.println("Enter your new element.:");
							int n2=sc.nextInt();
							dll.insertFirst(n2);
						}
						break;
				case 2 :{
							System.out.println("Please enter the element at Last.:");
							int n4=sc.nextInt();
							
							dll.insertLast(n4);
						}break;
				case 3:{
							System.out.println("Please enter the new element.:");
							int pos=sc.nextInt();
							int n3 = sc.nextInt();
							dll.inBetween(pos,n3);
						}break;
				case 4 :{
							dll.displayForward();
						}break;
				case 5 :{
							dll.displayBackward();
							
						}break;	
				case 6 :{
							dll.deleteFirst();
						}break;
				case 7 :{
							dll.deleteLast();
						}break;
				case 8:{
							System.out.println("Enter the position");
							int n5=sc.nextInt();
							dll.deletePosition(dll.head,n5);
						}break;
				default:{
							System.out.println("Try again");
						}
			}System.out.println("Do you want to continue the operation if select option y/n");
				ch=sc.next().charAt(0);
		}while(ch=='y'|| ch=='Y');
	}	
}