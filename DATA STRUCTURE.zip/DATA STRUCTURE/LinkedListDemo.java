import java.util.*;
class LinkedListDemo
{
	Node head;
	
	class Node{
		int data;
		Node next;
		
		Node(int d)
		{
			data = d;
			next = null;
		}
	}
	public void Push(int data)
	{
		Node new_node = new Node(data);
		
		new_node.next=head;
		head=new_node;
	}
	public void insertAfter(Node back_node,int new_data)
	{
		if(back_node == null)
		{
			System.out.println("given previously node cant null");
			return ;
		}
		Node new_node = new Node(new_data);
		new_node.next = back_node.next;
		back_node.next = new_node;
	}
	public void append(int new_data)
	{
		Node new_node = new Node(new_data);
		
		if(head==null)
		{
			head = new Node(new_data);
			return ;
		}
	new_node.next=null;
	Node back=head;
	
	while(back.next!=null)
		back=back.next;
	back.next = new_node;
	return;
}
public void deleteNode(int position)
{
	if(head==null)
	{
		return;
	}
	Node temp = head;
	if(position==0)
	{
		head=temp.next;
		return;
	}
	for(int i=0;temp!=null && i<position-1;i++)
	{
		temp=temp.next;
	}
	if(temp==null || temp.next==null)
	{
		return;
	}
	Node next = temp.next.next;
	temp.next=next;
}
public void printList()
{ 
   
	Node tnode=head;
	while(tnode!=null)
	
	{
		System.out.print("|"+tnode.data+"|"+"->");
		
		tnode=tnode.next;
	}
	System.out.println();
}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		//int num =sc.nextInt();
		LinkedListDemo LD = new LinkedListDemo();
		
		char ch;
		
		do
		{
			System.out.println("please enter the choice:");
			System.out.println("1.Insertion");
			System.out.println("2.InsertBetween");
			System.out.println("3.append");
			System.out.println("4.Show my LinkedList:");
			System.out.println("5.Delete element");
			int n =sc.nextInt();
			
			switch(n)
			{
				case 1: {
							System.out.println("Please insert your element.");
							int n1=sc.nextInt();
							LD.Push(n1);
						}break;
			   case 2: {
							System.out.println("Insert element in between:");
							int n2=sc.nextInt();
							LD.insertAfter(LD.head.next,n2);
						}break;
						
				case 3:{
							System.out.println("Append data.");
							int n3 =sc.nextInt();
							LD.append(n3);
						}break;
						
				case 4:{
							System.out.println("print the linked list :");
							LD.printList();
							
						}break;
				case 5:{
							System.out.println("Delete an element just enter the position:");
							int n4 = sc.nextInt();
							LD.deleteNode(n4);
							
						}break;			
				default:{
							System.out.println("Wrong Entry");
				}
		
				}
				System.out.println("Do you want to continue the operation if select option y/n");
				ch=sc.next().charAt(0);
		}while(ch=='y'|| ch=='Y');

	}
}