class FabRec
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System .out.println("Please enter the number");
		int num = nexInt();
		int n=0;
		int n1=0;
		System.out.print(n+" "+n+" ");
		for(int i=0;i<num;i++)
		{
			int num1 = n + n1;
			n=n1;
			n1=num1;
			System.out.println(num1+" ");
		}
	}
}
		