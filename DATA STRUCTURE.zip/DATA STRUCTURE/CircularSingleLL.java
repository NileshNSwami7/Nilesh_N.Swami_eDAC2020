import java.util.*;
class CircularSingleLL
{
	Node last;
	int length;
	
	class Node
	{
		Node next;
		int data;
	
		Node(int data)
		{
			this.data=data;
		}
	}
	
	public CircularSingleLL()
	{
		last=null;
		length=0;
	}
	
	public void insertCircularList(int ele[])
	{
		for(int i=0;i<ele.length;i++)
		{
			Node newNode = new Node(ele[i]);
			
			newNode.next=newNode;
			last=newNode;
		}
	}
	public void  printList()
	{
		
		if(last==null)
		{
			return;
		}
		Node first= last.next;
		while(first!=last)
		{
			System.out.println("["+first.data+"]"+"->");
			first = first.next;
		}
		System.out.println(first.data+ " ");
	}
	
	
	public int length()
	{
		return length;
	}
	
	public boolean isEmpty()
	{
		return length==0;
	}
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the size list.");
		int num = sc.nextInt();
		CircularSingleLL csll = new CircularSingleLL();
		
		int arr[]=new int[num];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		csll.insertCircularList(arr);
		csll.printList();
	}
}