

import java.util.Stack;

import Tree.BinaryTreeRecusive.TreeNode;

public class BinaryTreeIterative {
TreeNode root;
	
	private class TreeNode
	{
		TreeNode left;
		TreeNode right;
		int data;
		
		public TreeNode(int data)
		{
			this.data=data;
		}
	}
	
	public void createBinaryTree()
	{
		TreeNode first = new TreeNode(1);
		TreeNode second = new TreeNode(2);
		TreeNode third = new TreeNode(3);
		TreeNode fourth = new TreeNode(4);
		TreeNode five = new TreeNode(5);
		
		root = first;
		first.left=second;
		first.right=third;
		second.left=fourth;
		second.right=five;
	}
	public void preOrder(TreeNode root)
	{
		if(root==null)
			return ;
		Stack<TreeNode>stack = new Stack<>();
		stack.push(root);
		
		while(!stack.isEmpty())
		{
			TreeNode temp = stack.pop();
			System.out.println(temp.data+" ");
			if(temp.right!=null)
			{
				stack.push(temp.right);
			}
			if(temp.left != null)
			{
				stack.push(temp.left);
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinaryTreeIterative BIT = new BinaryTreeIterative();
		BIT.createBinaryTree();
		BIT.preOrder(BIT.root);
	}

}
