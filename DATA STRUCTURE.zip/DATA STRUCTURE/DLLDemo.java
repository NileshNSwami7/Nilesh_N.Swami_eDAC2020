import java.util.*;
public class DLLDemo
{
	Node head;
	class Node
	{
		int data;
		Node bckwrd;
		Node frwd;
		
		Node (int d)
		{
			data = d;
		}
	}
	
	public void push(int data[])
	{
		for(int i=0;i<data.length;i++)
		{
			Node newNode = new Node(data[i]);
			
			newNode.frwd = head;
			newNode.bckwrd = null;
			if(head!=null)
			
				head.frwd=newNode;
				
				head=newNode;
		}
	}
	public void insertAfter(Node pNode,int data[])
	{	
		if(pNode==null)
		{
			System.out.println("Preicouvs not can not be null");
			return;
		}
		for(int i=0;i<data.length;i++)
		{
			Node newNode = new Node(data[i]);
			
			newNode.frwd= pNode.frwd;
			pNode.frwd = newNode;
			newNode.bckwrd = pNode;
			if(newNode.frwd != null)
				newNode.frwd.frwd.bckwrd=newNode;
		}
	}
	public void printList(Node node)
	{
		Node last = null;
		System.out.println("Forward direction");
		while(node!=null)
		{
			System.out.print("|"+node.data+"|"+"->");
			last = node;
			node = node.frwd;
		}
		System.out.println();
		System.out.println("Backward direction");
		while(last !=null)
		{
			System.out.print("|"+last.data+"|"+"->");
			last = last.bckwrd;
		}
	}
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the size of your linked list.");
		int num=sc.nextInt();
		DLLDemo dl = new DLLDemo();
		
		char ch;
		
		do
		{
			System.out.println("Please enter the option :");
			System.out.println("1.create node");
			System.out.println("2.insertElment in between.");
			System.out.println("3.Show LinkedList");
			System.out.println("4.");
			
			int n1 = sc.nextInt();
			int arr[] = new int[num];
			switch (n1)
			{
				case 1 :{
							System.out.println("Please enter the element.");
							for(int i=0;i<arr.length;i++)
							{
								arr[i]=sc.nextInt();
							}
							dl.push(arr);
						}break;
				case 2 :{
							System.out.println("Please enter the:");
							int n2=sc.nextInt();
						//	dl.insertAfter(dl.head., n2);
						}break;
				case 3 :{
							System.out.println("Please enter the to see the LinkedList:");
							dl.printList(dl.head);
							
						}break;					
				default:{
							System.out.println("Try again");
						}
			}System.out.println("Do you want to continue the operation if select option y/n");
				ch=sc.next().charAt(0);
		}while(ch=='y'|| ch=='Y');
	}
}