import java.util.Scanner;

public class BubbleSort {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[10];
		int num;
		int temp=0;
		boolean flag=false;
		Scanner ip=new Scanner(System.in);
		System.out.println("Enter the element:");
		for(int i=0;i<10;i++)
		{
			num=ip.nextInt();
			arr[i]=num;
		}
		for(int i=0;i<10;i++)
		{
			flag=false;
			for(int j=0;j<10-i-1;j++)
			{
				if(arr[j]>=arr[j+1])
				{
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					flag=true;
				}
			}
			if(flag==false)
			{
				break;
			}
		}
		System.out.println("After Bubble Sortig elements are:");
		for(int i=0;i<10;i++)
		{
			System.out.print(" "+arr[i]);
		}
	}

}
