import java.util.*;
class QueueDemo
{
	int capacity;
	int queue[]=null;
	int rear=-1;
	int front=0;
	
	QueueDemo(int capacity)
	{
		this.capacity = capacity;
		queue = new int[capacity];
	}
	public void enqueue(int ele[])
	{
		if(isFull())
		{
			System.out.println("Queue is full cant insert");
			return;
		}
	
		for(int i=0;i<ele.length;i++)
		{
			//rear = rear+1;
			queue[++rear]= ele[i];
		}
		
	
	}
	public void dequeue()
	{
		if(isEmpty())
		{
			System.out.println("Queue is empty");
			return;
		}
		int ele = queue[front];
		for(int i=front;i<rear;i++)
		{
			queue[i]=queue[i+1];
		}
		rear--;
		System.out.println("dequeue elements:"+ele);
	}
	
	public int rear()
	{
		if(isEmpty())
		{
			System.out.println("Queue is Empty");
			return Integer.MIN_VALUE;
		}
		return queue[rear];
	}
	public int front()
	{
		if(isEmpty())
		{
			System.out.println("Queue is Empty");
			return Integer.MIN_VALUE;
		}
		return queue[front++];
	}

	public boolean isFull()
	{
		return size() == capacity;
	}
	
	public boolean isEmpty()
	{
		return size() == front;
	}
	
	public int size()
	{
		return rear+1;
	}

	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the size of Capacity of queue");
		int num = sc.nextInt();
		QueueDemo QD = new QueueDemo(num);
		char ch;
		do
		{
			System.out.println("Please select your operation of following list :");
			System.out.println("1.enqueue");
			System.out.println("2.dequeue");
			System.out.println("3.size");
			System.out.println("4.Rear");
			System.out.println("5.Front");
			
			int n = sc.nextInt();
			
			int arr[] = new int[num];
			switch(n)
			{
				case 1: {
							System.out.println("Please enter the element:");
							for(int i=0;i<num;i++)
							{
								arr[i]=sc.nextInt();
							}
							System.out.println("All your elements are in queue");
							QD.enqueue(arr);
						}break;
				case 2: {
							System.out.println("Dequeue all the elements:");
							for(int i=0;i<num;i++)
							{
								QD.dequeue();
							}
						}break;
						
				case 3:{
							System.out.println("Size of queue is :"+QD.size());
							QD.size();
						}break;
						
				case 4:{
							System.out.println("Rear of queue is :"+QD.rear());
							
						}break;
				case 5:{
							System.out.println("Front of queue is :"+QD.front());
							
						}break;
				
				default: {
							System.out.println("Wrong entry");
						 }
				}
				System.out.println("Do you want to continue the operatio if selct option y/n");
				ch=sc.next().charAt(0);
		}while(ch=='y'|| ch=='Y');
	}
}